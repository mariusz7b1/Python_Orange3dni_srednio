import math
print(math.sin(0.5*math.pi))
