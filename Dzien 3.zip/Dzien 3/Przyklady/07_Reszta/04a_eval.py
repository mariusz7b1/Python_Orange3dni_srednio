""" 
eval  wykonuje wyrażenia
"""
import os
os.system("cls")
war1 = 5

kod1 = "war1**3"
zm1 = eval(kod1)
print(zm1)

zm1 = 20
kod3 = "print(zm1)"
eval(kod3)


# kod1 = "war1=10"
# wynik = eval(kod1)  # to nie jest wyrażenie
