import math as m
print(m.sin(m.pi*0.5))
