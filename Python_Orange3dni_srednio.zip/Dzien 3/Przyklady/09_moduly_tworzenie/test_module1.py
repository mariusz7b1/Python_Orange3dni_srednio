"""Test modułow 1"""
from os import system
import mpmodul_1 as po
system('cls')


imie_kursanta = po.powitanie()
po.pozdrowienia(imie_kursanta)
